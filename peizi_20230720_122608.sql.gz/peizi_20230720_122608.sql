-- MariaDB dump 10.17  Distrib 10.5.6-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: peizi
-- ------------------------------------------------------
-- Server version	10.5.6-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pz_cms_city`
--

DROP TABLE IF EXISTS `pz_cms_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_cms_city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(70) DEFAULT NULL COMMENT '市区',
  `pid` int(11) DEFAULT NULL COMMENT 'pid',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=146211 DEFAULT CHARSET=utf8 COMMENT='市表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_cms_city`
--

LOCK TABLES `pz_cms_city` WRITE;
/*!40000 ALTER TABLE `pz_cms_city` DISABLE KEYS */;
INSERT INTO `pz_cms_city` VALUES (72,'朝阳区',1),(78,'黄浦区',2),(113,'万州区',4),(114,'涪陵区',4),(115,'梁平区',4),(119,'南川区',4),(123,'潼南区',4),(126,'大足区',4),(128,'黔江区',4),(129,'武隆区',4),(130,'丰都县',4),(131,'奉节县',4),(132,'开州区',4),(133,'云阳县',4),(134,'忠县',4),(135,'巫溪县',4),(136,'巫山县',4),(137,'石柱县',4),(138,'彭水县',4),(139,'垫江县',4),(140,'酉阳县',4),(141,'秀山县',4),(142,'石家庄市',5),(148,'邯郸市',5),(164,'邢台市',5),(199,'保定市',5),(224,'张家口市',5),(239,'承德市',5),(248,'秦皇岛市',5),(258,'唐山市',5),(264,'沧州市',5),(274,'廊坊市',5),(275,'衡水市',5),(303,'太原市',6),(309,'大同市',6),(318,'阳泉市',6),(325,'晋城市',6),(330,'朔州市',6),(336,'晋中市',6),(350,'忻州市',6),(368,'吕梁市',6),(379,'临汾市',6),(398,'运城市',6),(412,'郑州市',7),(420,'开封市',7),(427,'洛阳市',7),(438,'平顶山市',7),(446,'焦作市',7),(454,'鹤壁市',7),(458,'新乡市',7),(468,'安阳市',7),(475,'濮阳市',7),(482,'许昌市',7),(489,'漯河市',7),(495,'三门峡市',7),(502,'南阳市',7),(517,'商丘市',7),(527,'周口市',7),(538,'驻马店市',7),(549,'信阳市',7),(560,'沈阳市',8),(573,'大连市',8),(579,'鞍山市',8),(584,'抚顺市',8),(589,'本溪市',8),(593,'丹东市',8),(598,'锦州市',8),(604,'葫芦岛市',8),(609,'营口市',8),(613,'盘锦市',8),(617,'阜新市',8),(621,'辽阳市',8),(632,'朝阳市',8),(639,'长春市',9),(644,'吉林市',9),(651,'四平市',9),(657,'通化市',9),(664,'白山市',9),(674,'松原市',9),(681,'白城市',9),(687,'延边朝鲜族自治州',9),(698,'哈尔滨市',10),(712,'齐齐哈尔市',10),(727,'鹤岗市',10),(731,'双鸭山市',10),(737,'鸡西市',10),(742,'大庆市',10),(753,'伊春市',10),(757,'牡丹江市',10),(765,'佳木斯市',10),(773,'七台河市',10),(776,'黑河市',10),(782,'绥化市',10),(793,'大兴安岭地区',10),(799,'呼和浩特市',11),(805,'包头市',11),(810,'乌海市',11),(812,'赤峰市',11),(823,'乌兰察布市',11),(835,'锡林郭勒盟',11),(848,'呼伦贝尔市',11),(870,'鄂尔多斯市',11),(880,'巴彦淖尔市',11),(891,'阿拉善盟',11),(895,'兴安盟',11),(902,'通辽市',11),(904,'南京市',12),(911,'徐州市',12),(919,'连云港市',12),(925,'淮安市',12),(933,'宿迁市',12),(939,'盐城市',12),(951,'扬州市',12),(959,'泰州市',12),(965,'南通市',12),(972,'镇江市',12),(978,'常州市',12),(984,'无锡市',12),(988,'苏州市',12),(1000,'济南市',13),(1007,'青岛市',13),(1016,'淄博市',13),(1022,'枣庄市',13),(1025,'东营市',13),(1032,'潍坊市',13),(1042,'烟台市',13),(1053,'威海市',13),(1060,'德州市',13),(1072,'临沂市',13),(1081,'聊城市',13),(1090,'滨州市',13),(1099,'菏泽市',13),(1108,'日照市',13),(1112,'泰安市',13),(1114,'铜陵市',14),(1116,'合肥市',14),(1121,'淮南市',14),(1124,'淮北市',14),(1127,'芜湖市',14),(1132,'蚌埠市',14),(1137,'马鞍山市',14),(1140,'安庆市',14),(1151,'黄山市',14),(1158,'宁波市',15),(1159,'滁州市',14),(1167,'阜阳市',14),(1174,'亳州市',14),(1180,'宿州市',14),(1201,'池州市',14),(1206,'六安市',14),(1213,'杭州市',15),(1233,'温州市',15),(1243,'嘉兴市',15),(1250,'湖州市',15),(1255,'绍兴市',15),(1262,'金华市',15),(1273,'衢州市',15),(1280,'丽水市',15),(1290,'台州市',15),(1298,'舟山市',15),(1303,'福州市',16),(1315,'厦门市',16),(1317,'三明市',16),(1329,'莆田市',16),(1332,'泉州市',16),(1341,'漳州市',16),(1352,'南平市',16),(1362,'龙岩市',16),(1370,'宁德市',16),(1381,'武汉市',17),(1387,'黄石市',17),(1396,'襄阳市',17),(1405,'十堰市',17),(1413,'荆州市',17),(1421,'宜昌市',17),(1432,'孝感市',17),(1441,'黄冈市',17),(1458,'咸宁市',17),(1466,'恩施州',17),(1475,'鄂州市',17),(1477,'荆门市',17),(1479,'随州市',17),(1482,'长沙市',18),(1488,'株洲市',18),(1495,'湘潭市',18),(1501,'衡阳市',18),(1511,'邵阳市',18),(1522,'岳阳市',18),(1530,'常德市',18),(1540,'张家界市',18),(1544,'郴州市',18),(1555,'益阳市',18),(1560,'永州市',18),(1574,'怀化市',18),(1586,'娄底市',18),(1592,'湘西州',18),(1601,'广州市',19),(1607,'深圳市',19),(1609,'珠海市',19),(1611,'汕头市',19),(1617,'韶关市',19),(1627,'河源市',19),(1634,'梅州市',19),(1643,'惠州市',19),(1650,'汕尾市',19),(1655,'东莞市',19),(1657,'中山市',19),(1659,'江门市',19),(1666,'佛山市',19),(1672,'阳江市',19),(1677,'湛江市',19),(1684,'茂名市',19),(1690,'肇庆市',19),(1698,'云浮市',19),(1704,'清远市',19),(1705,'潮州市',19),(1709,'揭阳市',19),(1715,'南宁市',20),(1720,'柳州市',20),(1726,'桂林市',20),(1740,'梧州市',20),(1746,'北海市',20),(1749,'防城港市',20),(1753,'钦州市',20),(1757,'贵港市',20),(1761,'玉林市',20),(1792,'贺州市',20),(1806,'百色市',20),(1818,'河池市',20),(1827,'南昌市',21),(1832,'景德镇市',21),(1836,'萍乡市',21),(1842,'新余市',21),(1845,'九江市',21),(1857,'鹰潭市',21),(1861,'上饶市',21),(1874,'宜春市',21),(1885,'抚州市',21),(1898,'吉安市',21),(1911,'赣州市',21),(1930,'成都市',22),(1946,'自贡市',22),(1950,'攀枝花市',22),(1954,'泸州市',22),(1960,'绵阳市',22),(1962,'德阳市',22),(1977,'广元市',22),(1983,'遂宁市',22),(1988,'内江市',22),(1993,'乐山市',22),(2005,'宜宾市',22),(2016,'广安市',22),(2022,'南充市',22),(2033,'达州市',22),(2042,'巴中市',22),(2047,'雅安市',22),(2058,'眉山市',22),(2065,'资阳市',22),(2070,'阿坝州',22),(2084,'甘孜州',22),(2103,'凉山州',22),(2121,'海口市',23),(2144,'贵阳市',24),(2150,'六盘水市',24),(2155,'遵义市',24),(2169,'铜仁市',24),(2180,'毕节市',24),(2189,'安顺市',24),(2196,'黔西南州',24),(2205,'黔东南州',24),(2222,'黔南州',24),(2235,'昆明市',25),(2247,'曲靖市',25),(2258,'玉溪市',25),(2270,'昭通市',25),(2281,'普洱市',25),(2291,'临沧市',25),(2298,'保山市',25),(2304,'丽江市',25),(2309,'文山州',25),(2318,'红河州',25),(2332,'西双版纳州',25),(2336,'楚雄州',25),(2347,'大理州',25),(2360,'德宏州',25),(2366,'怒江州',25),(2376,'西安市',27),(2386,'铜川市',27),(2390,'宝鸡市',27),(2402,'咸阳市',27),(2416,'渭南市',27),(2428,'延安市',27),(2442,'汉中市',27),(2454,'榆林市',27),(2468,'商洛市',27),(2476,'安康市',27),(2487,'兰州市',28),(2492,'金昌市',28),(2495,'白银市',28),(2501,'天水市',28),(2509,'嘉峪关市',28),(2518,'平凉市',28),(2525,'庆阳市',28),(2534,'陇南市',28),(2544,'武威市',28),(2549,'张掖市',28),(2556,'酒泉市',28),(2564,'甘南州',28),(2573,'临夏州',28),(2580,'西宁市',29),(2585,'海东地区',29),(2592,'海北州',29),(2597,'黄南州',29),(2603,'海南州',29),(2605,'果洛州',29),(2612,'玉树州',29),(2620,'海西州',29),(2628,'银川市',30),(2632,'石嘴山市',30),(2637,'吴忠市',30),(2644,'固原市',30),(2652,'乌鲁木齐市',31),(2654,'克拉玛依市',31),(2656,'石河子市',31),(2658,'吐鲁番地区',31),(2662,'哈密地区',31),(2666,'和田地区',31),(2675,'阿克苏地区',31),(2686,'喀什地区',31),(2699,'克孜勒苏柯尔克孜自治州',31),(2704,'巴音郭楞州',31),(2714,'昌吉州',31),(2723,'博尔塔拉州',31),(2727,'伊犁州',31),(2736,'塔城地区',31),(2744,'阿勒泰地区',31),(2768,'中国台湾',32),(2780,'济源市',7),(2800,'海淀区',1),(2801,'西城区',1),(2802,'东城区',1),(2805,'丰台区',1),(2806,'石景山区',1),(2807,'门头沟',1),(2808,'房山区',1),(2809,'通州区',1),(2810,'大兴区',1),(2812,'顺义区',1),(2813,'徐汇区',2),(2814,'怀柔区',1),(2815,'长宁区',2),(2816,'密云区',1),(2817,'静安区',2),(2822,'虹口区',2),(2823,'杨浦区',2),(2824,'宝山区',2),(2825,'闵行区',2),(2826,'嘉定区',2),(2830,'浦东新区',2),(2833,'青浦区',2),(2834,'松江区',2),(2835,'金山区',2),(2837,'奉贤区',2),(2841,'普陀区',2),(2900,'济宁市',13),(2901,'昌平区',1),(2919,'崇明区',2),(2922,'潜江市',17),(2951,'拉萨市',26),(2953,'平谷区',1),(2971,'宣城市',14),(2980,'天门市',17),(2983,'仙桃市',17),(2992,'辽源市',9),(3034,'儋州市',23),(3044,'来宾市',20),(3065,'延庆区',1),(3071,'中卫市',30),(3074,'长治市',6),(3080,'定西市',28),(3107,'那曲地区',26),(3115,'琼海市',23),(3129,'山南地区',26),(3137,'万宁市',23),(3138,'昌都地区',26),(3144,'日喀则地区',26),(3154,'神农架林区',17),(3168,'崇左市',20),(3173,'东方市',23),(3690,'三亚市',23),(3698,'文昌市',23),(3699,'五指山市',23),(3701,'临高县',23),(3702,'澄迈县',23),(3703,'定安县',23),(3704,'屯昌县',23),(3705,'昌江县',23),(3706,'白沙县',23),(3707,'琼中县',23),(3708,'陵水县',23),(3709,'保亭县',23),(3710,'乐东县',23),(3711,'三沙市',23),(3970,'阿里地区',26),(3971,'林芝市',26),(4108,'迪庆州',25),(4110,'五家渠市',31),(4164,'城口县',4),(6858,'铁岭市',8),(15945,'阿拉尔市',31),(15946,'图木舒克市',31),(48131,'璧山区',4),(48132,'荣昌区',4),(48133,'铜梁区',4),(48201,'合川区',4),(48202,'巴南区',4),(48203,'北碚区',4),(48204,'江津区',4),(48205,'渝北区',4),(48206,'长寿区',4),(48207,'永川区',4),(50950,'江北区',4),(50951,'南岸区',4),(50952,'九龙坡区',4),(50953,'沙坪坝区',4),(50954,'大渡口区',4),(50995,'綦江区',4),(51026,'渝中区',4),(51035,'东丽区',3),(51036,'和平区',3),(51037,'河北区',3),(51038,'河东区',3),(51039,'河西区',3),(51040,'红桥区',3),(51041,'蓟州区',3),(51042,'静海区',3),(51043,'南开区',3),(51044,'滨海新区',3),(51045,'西青区',3),(51046,'武清区',3),(51047,'津南区',3),(51049,'大港区',3),(51050,'北辰区',3),(51051,'宝坻区',3),(51052,'宁河区',3),(52994,'中国香港',52993),(52995,'中国澳门',52993),(53090,'铁门关市',31),(53668,'昆玉市',31),(129142,'北屯市',31),(145492,'可克达拉市',31),(146206,'胡杨河市',31),(146207,'市辖区',1),(146208,'市辖区',2),(146209,'市辖区',3),(146210,'市辖区',4);
/*!40000 ALTER TABLE `pz_cms_city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_cms_navs`
--

DROP TABLE IF EXISTS `pz_cms_navs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_cms_navs` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `pid` int(11) NOT NULL DEFAULT 0 COMMENT '父id',
  `title` char(200) DEFAULT NULL COMMENT '标题',
  `keywords` varchar(200) DEFAULT NULL COMMENT '关键词',
  `description` varchar(400) DEFAULT NULL COMMENT '描述',
  `name` char(150) DEFAULT NULL COMMENT '名称',
  `model` char(50) DEFAULT NULL,
  `wap_name` char(100) DEFAULT NULL COMMENT '手机导航名称',
  `urls` char(150) DEFAULT NULL COMMENT 'url地址',
  `iconfont` char(50) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态',
  `sort` int(3) DEFAULT NULL COMMENT '排序',
  `table_name` char(50) DEFAULT NULL COMMENT '表名',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='栏目表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_cms_navs`
--

LOCK TABLES `pz_cms_navs` WRITE;
/*!40000 ALTER TABLE `pz_cms_navs` DISABLE KEYS */;
INSERT INTO `pz_cms_navs` VALUES (1,0,'配资指数数据-peizizhishu.com,配资平台数据大全,最真实的配资评论','配资指数数据-peizizhishu.com,配资平台数据大全,最真实的配资评论','配资指数数据-peizizhishu.com,配资平台数据大全,最真实的配资评论','配资平台数据','plateform','数据','plateform','icon-odbc',1,5,'cms_plateform',1689414241,1689477184,NULL),(2,0,'配资新闻资讯','配资新闻资讯','配资新闻资讯','配资新闻','news','新闻','news','icon-zixun',1,4,'cms_news',1689414386,1689646616,NULL),(3,0,'配资平台录入','配资平台录入','配资平台录入','配资平台录入','add','加入','add','icon-dc-icon-pingtaigongshouluqiye',1,3,'cms_plateform',1689415129,1689477189,NULL),(4,0,'配资平台曝光','配资平台曝光','配资平台曝光','配资平台曝光','warn','曝光','warning','icon-puguang',1,2,'cms_warn',1689415164,1689477191,NULL);
/*!40000 ALTER TABLE `pz_cms_navs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_cms_news`
--

DROP TABLE IF EXISTS `pz_cms_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_cms_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `title` varchar(300) DEFAULT NULL COMMENT '标题',
  `description` varchar(300) DEFAULT NULL COMMENT '描述',
  `keywords` varchar(300) DEFAULT NULL COMMENT '关键词',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态',
  `pic` varchar(300) DEFAULT NULL COMMENT '图片',
  `content` text DEFAULT NULL COMMENT '内容',
  `author` char(100) DEFAULT NULL COMMENT '作者',
  `num` int(10) NOT NULL DEFAULT 0 COMMENT '阅读次数',
  `pub_time` datetime DEFAULT NULL COMMENT '发布时间',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='新闻列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_cms_news`
--

LOCK TABLES `pz_cms_news` WRITE;
/*!40000 ALTER TABLE `pz_cms_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `pz_cms_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_cms_plateback`
--

DROP TABLE IF EXISTS `pz_cms_plateback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_cms_plateback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(300) DEFAULT NULL COMMENT '名称',
  `website` varchar(300) DEFAULT NULL COMMENT '网址',
  `images` text DEFAULT NULL COMMENT '图片',
  `qq` char(50) DEFAULT NULL COMMENT 'qq',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '状态',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='平台反馈';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_cms_plateback`
--

LOCK TABLES `pz_cms_plateback` WRITE;
/*!40000 ALTER TABLE `pz_cms_plateback` DISABLE KEYS */;
/*!40000 ALTER TABLE `pz_cms_plateback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_cms_plateform`
--

DROP TABLE IF EXISTS `pz_cms_plateform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_cms_plateform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(300) DEFAULT NULL COMMENT '平台名称',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态',
  `pstatus` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 在业 2异常 3停业 4 失联',
  `logo` char(200) DEFAULT NULL COMMENT '平台logo',
  `min_logo` char(100) DEFAULT NULL COMMENT '小logo',
  `class` tinyint(1) DEFAULT 1 COMMENT '分类 1 期货 2股票',
  `safe` int(3) DEFAULT NULL COMMENT '安全性',
  `cost` char(20) DEFAULT NULL COMMENT '资金成本',
  `website` char(240) DEFAULT NULL COMMENT '网址',
  `other_website` varchar(500) DEFAULT NULL COMMENT '其他网址',
  `main_business` char(200) DEFAULT NULL COMMENT '主营业务',
  `province` char(100) DEFAULT NULL COMMENT '省',
  `city` char(100) DEFAULT NULL COMMENT '市',
  `office_address` char(250) DEFAULT NULL COMMENT '办公地址',
  `launch_date` varchar(50) DEFAULT NULL COMMENT '上线时间',
  `customer_service` char(100) DEFAULT NULL COMMENT '客服热线',
  `company_name` char(100) DEFAULT NULL COMMENT '公司名称',
  `credit_code` char(100) DEFAULT NULL COMMENT '信用代码',
  `operating_status` char(100) DEFAULT NULL COMMENT '经营状态',
  `legal_representative` char(50) DEFAULT NULL COMMENT '法人',
  `company_type` char(150) DEFAULT NULL COMMENT '公司类型',
  `establishment_date` varchar(50) DEFAULT NULL COMMENT '成立日期',
  `registered_capital` char(50) DEFAULT NULL COMMENT '注册资本',
  `registered_address` varchar(300) DEFAULT NULL COMMENT '注册地址',
  `organizer_name` char(250) DEFAULT NULL COMMENT '主办单位',
  `website_name` char(250) DEFAULT NULL COMMENT '网站名称',
  `domain_name` char(250) DEFAULT NULL COMMENT '网站域名',
  `website_record` char(100) DEFAULT NULL COMMENT '网站备案',
  `organizer_type` char(150) DEFAULT NULL COMMENT '主办单位性质',
  `homepage_address` char(150) DEFAULT NULL COMMENT '首页地址',
  `website_manager` char(150) DEFAULT NULL COMMENT '负责人',
  `review_date` varchar(50) DEFAULT NULL COMMENT '审核时间',
  `document_file` text DEFAULT NULL COMMENT '公司证件',
  `images` text DEFAULT NULL COMMENT '香关图片',
  `description` text DEFAULT NULL COMMENT '平台简介',
  `warn_ids` varchar(300) DEFAULT NULL COMMENT '相关曝光',
  `financing_information` text DEFAULT NULL COMMENT '融资信息',
  `summarize` text DEFAULT NULL COMMENT '总结',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `pstatus` (`pstatus`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='配资平台';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_cms_plateform`
--

LOCK TABLES `pz_cms_plateform` WRITE;
/*!40000 ALTER TABLE `pz_cms_plateform` DISABLE KEYS */;
/*!40000 ALTER TABLE `pz_cms_plateform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_cms_province`
--

DROP TABLE IF EXISTS `pz_cms_province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_cms_province` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(40) NOT NULL COMMENT '省',
  `num` int(5) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=52994 DEFAULT CHARSET=utf8 COMMENT='省份表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_cms_province`
--

LOCK TABLES `pz_cms_province` WRITE;
/*!40000 ALTER TABLE `pz_cms_province` DISABLE KEYS */;
INSERT INTO `pz_cms_province` VALUES (1,'北京',0),(2,'上海',1),(3,'天津',0),(4,'重庆',0),(5,'河北',0),(6,'山西',1),(7,'河南',0),(8,'辽宁',0),(9,'吉林',0),(10,'黑龙江',0),(11,'内蒙古',0),(12,'江苏',0),(13,'山东',0),(14,'安徽',0),(15,'浙江',0),(16,'福建',1),(17,'湖北',0),(18,'湖南',0),(19,'广东',0),(20,'广西',1),(21,'江西',0),(22,'四川',1),(23,'海南',0),(24,'贵州',0),(25,'云南',0),(26,'西藏',0),(27,'陕西',0),(28,'甘肃',0),(29,'青海',0),(30,'宁夏',0),(31,'新疆',0),(32,'台湾',0),(52993,'港澳',0);
/*!40000 ALTER TABLE `pz_cms_province` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_cms_warn`
--

DROP TABLE IF EXISTS `pz_cms_warn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_cms_warn` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `title` char(250) DEFAULT NULL COMMENT '标题',
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '状态',
  `isread` tinyint(1) NOT NULL DEFAULT 1,
  `class` tinyint(1) NOT NULL DEFAULT 1,
  `logo` char(200) DEFAULT NULL COMMENT 'logo',
  `min_logo` char(200) DEFAULT NULL,
  `website` char(200) DEFAULT NULL,
  `plateform` char(200) DEFAULT NULL COMMENT '平台',
  `content` text DEFAULT NULL COMMENT '描述',
  `report` text DEFAULT NULL COMMENT '后续报道',
  `summary` text DEFAULT NULL COMMENT '总结',
  `pub_time` datetime DEFAULT NULL,
  `num` int(5) NOT NULL DEFAULT 0,
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='预警曝光';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_cms_warn`
--

LOCK TABLES `pz_cms_warn` WRITE;
/*!40000 ALTER TABLE `pz_cms_warn` DISABLE KEYS */;
/*!40000 ALTER TABLE `pz_cms_warn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_config_attr`
--

DROP TABLE IF EXISTS `pz_config_attr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_config_attr` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL COMMENT '属性名称',
  `value` varchar(150) DEFAULT NULL COMMENT '属性值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_config_attr`
--

LOCK TABLES `pz_config_attr` WRITE;
/*!40000 ALTER TABLE `pz_config_attr` DISABLE KEYS */;
INSERT INTO `pz_config_attr` VALUES (1,'文本框','text'),(2,'单选框','radio'),(3,'多行文本','textarea'),(4,'图片','img'),(5,'网站模板','tpl');
/*!40000 ALTER TABLE `pz_config_attr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_config_group`
--

DROP TABLE IF EXISTS `pz_config_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_config_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL COMMENT '分组名称',
  `value` varchar(250) NOT NULL COMMENT '分组标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_config_group`
--

LOCK TABLES `pz_config_group` WRITE;
/*!40000 ALTER TABLE `pz_config_group` DISABLE KEYS */;
INSERT INTO `pz_config_group` VALUES (1,'网站配置','web'),(2,'核心配置','system');
/*!40000 ALTER TABLE `pz_config_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_config_index`
--

DROP TABLE IF EXISTS `pz_config_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_config_index` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL COMMENT '名称',
  `title` varchar(250) DEFAULT NULL COMMENT '标题',
  `value` text DEFAULT NULL COMMENT '值',
  `groupid` int(11) DEFAULT NULL COMMENT '分组',
  `type` int(5) DEFAULT NULL COMMENT '类型',
  `content` varchar(250) DEFAULT NULL COMMENT '说明',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COMMENT='网站配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_config_index`
--

LOCK TABLES `pz_config_index` WRITE;
/*!40000 ALTER TABLE `pz_config_index` DISABLE KEYS */;
INSERT INTO `pz_config_index` VALUES (1,'web_title','网站标题','配资指数-peizizhishu.com,看平台口碑,最真实的配资评论',1,1,'标题',1649489303,1649489303,NULL),(2,'web_keywords','关键词','配资指数,peizizhishu.com,最真实的配资评论,股票配资平台,配资平台口碑,配资平台曝光,配资平台异常,最真实的配资评论',1,1,'',1649489752,1649489752,NULL),(3,'web_description','网站描述','配资指数,peizizhishu.com,最真实的配资评论,股票配资平台,配资平台口碑,配资平台曝光,配资平台异常,最真实的配资评论',1,1,'',1649489793,1649489793,NULL),(4,'web_logo','网站logo','/upload/20230715/2ff996a9d0733e33267522001102d619.jpg',1,4,'',1649489897,1649489897,NULL),(5,'web_url','网址','http://c.youku10.com',1,1,'',1649489943,1649489943,NULL),(6,'web_copyright','版权信息','©配资指数 peizizhishu.com 版权所有',1,1,'',1649490004,1649490004,NULL),(7,'web_icp','备案号','粤ICP备15024978号',1,1,'',1649490034,1649490034,NULL),(8,'web_skype','skype联系方式','kefu@peizizhishu.com',1,1,'',1689474834,1689474834,NULL),(9,'web_email','邮箱','kefu@peizizhishu.com',1,1,'邮箱',1689474861,1689474861,NULL),(10,'web_skype_cid','skype的cid(账号)','skype:live:.cid.ac8033098a387021?chat',1,1,'',1689475202,1689475202,NULL),(11,'web_footer','网站底部','&lt;p&gt;《证券法》第一百二十条规定&amp;quot;除证券公司外，任何单位和个人不得从事证券承销、证券保荐、证券经纪和证券融资融券业务。&lt;/p&gt;\n\n&lt;p&gt;指数依据配资人反馈信息及时汇总公示，仅供参考。免费提供的平台数据以及其他资料均来自第三方，仅作为用户获取信息之目的，并不构成投资建议。&lt;/p&gt;\n\n&lt;p&gt;指数以及其合作机构不为本页面提供的信息错误、残缺、延时或因依靠此信息所采取的任何行动负责。市场有风险，投资需谨慎。&lt;/p&gt;\n',1,3,'',1689475889,1689475889,NULL),(12,'web_hot_search','热搜词','信汇网|卓信宝|天天盈',1,1,'热搜词|隔开',1689499066,1689499066,NULL),(13,'cache_time','缓存时间','3600',2,1,'缓存时间',1689502608,1689502608,NULL),(14,'upload_size','最大上传','512000',2,1,'',1689514219,1689514616,NULL),(15,'upload_allow_ext','上传类型','jpg,jpge,gif,png',2,1,'',1689514280,1689514280,NULL),(16,'web_domain','网站域名','xhshhxx.com',1,1,'',1689578589,1689578589,NULL),(17,'web_kefu','客服链接','http://www.kefu.com',1,1,'',1689821498,1689821498,NULL);
/*!40000 ALTER TABLE `pz_config_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_mall_cate`
--

DROP TABLE IF EXISTS `pz_mall_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_mall_cate` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL COMMENT '分类名',
  `image` varchar(500) DEFAULT NULL COMMENT '分类图片',
  `sort` int(11) DEFAULT 0 COMMENT '排序',
  `status` tinyint(1) unsigned DEFAULT 1 COMMENT '状态(1:禁用,2:启用)',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='商品分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_mall_cate`
--

LOCK TABLES `pz_mall_cate` WRITE;
/*!40000 ALTER TABLE `pz_mall_cate` DISABLE KEYS */;
INSERT INTO `pz_mall_cate` VALUES (9,'手机','http://admin.host/upload/20200514/98fc09b0c4ad4d793a6f04bef79a0edc.jpg',0,1,'',1589440437,1589440437,NULL);
/*!40000 ALTER TABLE `pz_mall_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_mall_goods`
--

DROP TABLE IF EXISTS `pz_mall_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_mall_goods` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` int(11) DEFAULT NULL COMMENT '分类ID',
  `title` varchar(20) NOT NULL COMMENT '商品名称',
  `logo` varchar(500) DEFAULT NULL COMMENT '商品logo',
  `images` text DEFAULT NULL COMMENT '商品图片 以 | 做分割符号',
  `describe` text DEFAULT NULL COMMENT '商品描述',
  `market_price` decimal(10,2) DEFAULT 0.00 COMMENT '市场价',
  `discount_price` decimal(10,2) DEFAULT 0.00 COMMENT '折扣价',
  `sales` int(11) DEFAULT 0 COMMENT '销量',
  `virtual_sales` int(11) DEFAULT 0 COMMENT '虚拟销量',
  `stock` int(11) DEFAULT 0 COMMENT '库存',
  `total_stock` int(11) DEFAULT 0 COMMENT '总库存',
  `sort` int(11) DEFAULT 0 COMMENT '排序',
  `status` tinyint(1) unsigned DEFAULT 1 COMMENT '状态(1:禁用,2:启用)',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `cate_id` (`cate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='商品列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_mall_goods`
--

LOCK TABLES `pz_mall_goods` WRITE;
/*!40000 ALTER TABLE `pz_mall_goods` DISABLE KEYS */;
INSERT INTO `pz_mall_goods` VALUES (8,10,'落地-风扇','http://admin.host/upload/20200514/a0f7fe9637abd219f7e93ceb2820df9b.jpg','http://admin.host/upload/20200514/95496713918290f6315ea3f87efa6bf2.jpg|http://admin.host/upload/20200514/ae29fa9cba4fc02defb7daed41cb2b13.jpg|http://admin.host/upload/20200514/f0a104d88ec7dc6fb42d2f87cbc71b76.jpg|http://admin.host/upload/20200514/3b88be4b1934690e5c1bd6b54b9ab5c8.jpg','<p>76654757</p>\n\n<p><img alt=\"\" src=\"http://admin.host/upload/20200515/198070421110fa01f2c2ac2f52481647.jpg\" style=\"height:689px; width:790px\" /></p>\n\n<p><img alt=\"\" src=\"http://admin.host/upload/20200515/a07a742c15a78781e79f8a3317006c1d.jpg\" style=\"height:877px; width:790px\" /></p>\n',599.00,368.00,0,594,0,0,675,1,'',1589454309,1589567016,NULL),(9,9,'电脑','http://admin.host/upload/20200514/bbf858d469dec2e12a89460110068d3d.jpg','http://admin.host/upload/20200514/f0a104d88ec7dc6fb42d2f87cbc71b76.jpg','<p>477</p>\n',0.00,0.00,0,0,115,320,0,1,'',1589465215,1589476345,NULL);
/*!40000 ALTER TABLE `pz_mall_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_system_admin`
--

DROP TABLE IF EXISTS `pz_system_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_system_admin` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `auth_ids` varchar(255) DEFAULT NULL COMMENT '角色权限ID',
  `head_img` varchar(255) DEFAULT NULL COMMENT '头像',
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '用户登录名',
  `password` char(40) NOT NULL DEFAULT '' COMMENT '用户登录密码',
  `phone` varchar(16) DEFAULT NULL COMMENT '联系手机号',
  `remark` varchar(255) DEFAULT '' COMMENT '备注说明',
  `login_num` bigint(20) unsigned DEFAULT 0 COMMENT '登录次数',
  `sort` int(11) DEFAULT 0 COMMENT '排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '状态(0:禁用,1:启用,)',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE,
  KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='系统用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_system_admin`
--

LOCK TABLES `pz_system_admin` WRITE;
/*!40000 ALTER TABLE `pz_system_admin` DISABLE KEYS */;
INSERT INTO `pz_system_admin` VALUES (1,NULL,'/static/admin/images/head.jpg','tianxin','ed696eb5bba1f7460585cc6975e6cf9bf24903dd',NULL,'',7,0,1,1689403581,1689820854,NULL);
/*!40000 ALTER TABLE `pz_system_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_system_auth`
--

DROP TABLE IF EXISTS `pz_system_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_system_auth` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL COMMENT '权限名称',
  `sort` int(11) DEFAULT 0 COMMENT '排序',
  `status` tinyint(1) unsigned DEFAULT 1 COMMENT '状态(1:禁用,2:启用)',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='系统权限表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_system_auth`
--

LOCK TABLES `pz_system_auth` WRITE;
/*!40000 ALTER TABLE `pz_system_auth` DISABLE KEYS */;
INSERT INTO `pz_system_auth` VALUES (1,'管理员',1,1,'测试管理员',1588921753,1589614331,NULL),(6,'游客权限',0,1,'',1588227513,1589591751,1589591751);
/*!40000 ALTER TABLE `pz_system_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_system_auth_node`
--

DROP TABLE IF EXISTS `pz_system_auth_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_system_auth_node` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `auth_id` bigint(20) unsigned DEFAULT NULL COMMENT '角色ID',
  `node_id` bigint(20) DEFAULT NULL COMMENT '节点ID',
  PRIMARY KEY (`id`),
  KEY `index_system_auth_auth` (`auth_id`) USING BTREE,
  KEY `index_system_auth_node` (`node_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='角色与节点关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_system_auth_node`
--

LOCK TABLES `pz_system_auth_node` WRITE;
/*!40000 ALTER TABLE `pz_system_auth_node` DISABLE KEYS */;
INSERT INTO `pz_system_auth_node` VALUES (1,6,1),(2,6,2),(3,6,9),(4,6,12),(5,6,18),(6,6,19),(7,6,21),(8,6,22),(9,6,29),(10,6,30),(11,6,38),(12,6,39),(13,6,45),(14,6,46),(15,6,52),(16,6,53);
/*!40000 ALTER TABLE `pz_system_auth_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_system_config`
--

DROP TABLE IF EXISTS `pz_system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_system_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '变量名',
  `group` varchar(30) NOT NULL DEFAULT '' COMMENT '分组',
  `value` text DEFAULT NULL COMMENT '变量值',
  `remark` varchar(100) DEFAULT '' COMMENT '备注信息',
  `sort` int(10) DEFAULT 0,
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `group` (`group`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='系统配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_system_config`
--

LOCK TABLES `pz_system_config` WRITE;
/*!40000 ALTER TABLE `pz_system_config` DISABLE KEYS */;
INSERT INTO `pz_system_config` VALUES (41,'alisms_access_key_id','sms','填你的','阿里大于公钥',0,NULL,NULL),(42,'alisms_access_key_secret','sms','填你的','阿里大鱼私钥',0,NULL,NULL),(55,'upload_type','upload','local','当前上传方式 （local,alioss,qnoss,txoss）',0,NULL,NULL),(56,'upload_allow_ext','upload','doc,gif,ico,icon,jpg,mp3,mp4,p12,pem,png,rar,jpeg','允许上传的文件类型',0,NULL,NULL),(57,'upload_allow_size','upload','1024000','允许上传的大小',0,NULL,NULL),(58,'upload_allow_mime','upload','image/gif,image/jpeg,video/x-msvideo,text/plain,image/png','允许上传的文件mime',0,NULL,NULL),(59,'upload_allow_type','upload','local,alioss,qnoss,txcos','可用的上传文件方式',0,NULL,NULL),(60,'alioss_access_key_id','upload','填你的','阿里云oss公钥',0,NULL,NULL),(61,'alioss_access_key_secret','upload','填你的','阿里云oss私钥',0,NULL,NULL),(62,'alioss_endpoint','upload','填你的','阿里云oss数据中心',0,NULL,NULL),(63,'alioss_bucket','upload','填你的','阿里云oss空间名称',0,NULL,NULL),(64,'alioss_domain','upload','填你的','阿里云oss访问域名',0,NULL,NULL),(65,'logo_title','site','配资后台系统','LOGO标题',0,NULL,NULL),(66,'logo_image','site','/favicon.ico','logo图片',0,NULL,NULL),(68,'site_name','site','配资后台系统','站点名称',0,NULL,NULL),(69,'site_ico','site','填你的','浏览器图标',0,NULL,NULL),(70,'site_copyright','site','填你的','版权信息',0,NULL,NULL),(71,'site_beian','site','填你的','备案信息',0,NULL,NULL),(72,'site_version','site','2.0.0','版本信息',0,NULL,NULL),(75,'sms_type','sms','alisms','短信类型',0,NULL,NULL),(76,'miniapp_appid','wechat','填你的','小程序公钥',0,NULL,NULL),(77,'miniapp_appsecret','wechat','填你的','小程序私钥',0,NULL,NULL),(78,'web_appid','wechat','填你的','公众号公钥',0,NULL,NULL),(79,'web_appsecret','wechat','填你的','公众号私钥',0,NULL,NULL),(80,'txcos_secret_id','upload','填你的','腾讯云cos密钥',0,NULL,NULL),(81,'txcos_secret_key','upload','填你的','腾讯云cos私钥',0,NULL,NULL),(82,'txcos_region','upload','填你的','存储桶地域',0,NULL,NULL),(83,'tecos_bucket','upload','填你的','存储桶名称',0,NULL,NULL),(84,'qnoss_access_key','upload','填你的','访问密钥',0,NULL,NULL),(85,'qnoss_secret_key','upload','填你的','安全密钥',0,NULL,NULL),(86,'qnoss_bucket','upload','填你的','存储空间',0,NULL,NULL),(87,'qnoss_domain','upload','填你的','访问域名',0,NULL,NULL);
/*!40000 ALTER TABLE `pz_system_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_system_log_202307`
--

DROP TABLE IF EXISTS `pz_system_log_202307`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_system_log_202307` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int(10) unsigned DEFAULT 0 COMMENT '管理员ID',
  `url` varchar(1500) NOT NULL DEFAULT '' COMMENT '操作页面',
  `method` varchar(50) NOT NULL COMMENT '请求方法',
  `title` varchar(100) DEFAULT '' COMMENT '日志标题',
  `content` text NOT NULL COMMENT '内容',
  `ip` varchar(50) NOT NULL DEFAULT '' COMMENT 'IP',
  `useragent` varchar(255) DEFAULT '' COMMENT 'User-Agent',
  `create_time` int(10) DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='后台操作日志表 - 202307';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_system_log_202307`
--

LOCK TABLES `pz_system_log_202307` WRITE;
/*!40000 ALTER TABLE `pz_system_log_202307` DISABLE KEYS */;
/*!40000 ALTER TABLE `pz_system_log_202307` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_system_menu`
--

DROP TABLE IF EXISTS `pz_system_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_system_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pid` bigint(20) unsigned NOT NULL DEFAULT 0 COMMENT '父id',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '名称',
  `icon` varchar(100) NOT NULL DEFAULT '' COMMENT '菜单图标',
  `href` varchar(100) NOT NULL DEFAULT '' COMMENT '链接',
  `params` varchar(500) DEFAULT '' COMMENT '链接参数',
  `target` varchar(20) NOT NULL DEFAULT '_self' COMMENT '链接打开方式',
  `sort` int(11) DEFAULT 0 COMMENT '菜单排序',
  `status` tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '状态(0:禁用,1:启用)',
  `remark` varchar(255) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `title` (`title`),
  KEY `href` (`href`)
) ENGINE=InnoDB AUTO_INCREMENT=266 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='系统菜单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_system_menu`
--

LOCK TABLES `pz_system_menu` WRITE;
/*!40000 ALTER TABLE `pz_system_menu` DISABLE KEYS */;
INSERT INTO `pz_system_menu` VALUES (227,99999999,'后台首页','fa fa-home','index/welcome','','_self',0,1,NULL,NULL,1573120497,NULL),(228,0,'系统管理','fa fa-cog','','','_self',0,1,'',NULL,1588999529,NULL),(234,228,'菜单管理','fa fa-tree','system.menu/index','','_self',10,1,'',NULL,1588228555,NULL),(244,228,'管理员管理','fa fa-user','system.admin/index','','_self',12,1,'',1573185011,1588228573,NULL),(245,228,'角色管理','fa fa-bitbucket-square','system.auth/index','','_self',11,1,'',1573435877,1588228634,NULL),(246,228,'节点管理','fa fa-list','system.node/index','','_self',9,1,'',1573435919,1588228648,NULL),(247,228,'配置管理','fa fa-asterisk','','','_self',8,1,'',1573457448,1689416628,NULL),(248,228,'上传管理','fa fa-arrow-up','system.uploadfile/index','','_self',0,1,'',1573542953,1588228043,NULL),(249,0,'内容管理','fa fa-list','','','_self',5,1,'',1589439884,1689413410,NULL),(250,249,'栏目管理','fa fa-navicon','cms.navs/index','','_self',9,1,'',1589439910,1689512701,NULL),(251,249,'新闻管理','fa fa-newspaper-o','cms.news/index','','_self',8,1,'',1589439931,1689512705,NULL),(252,228,'快捷入口','fa fa-list','system.quick/index','','_self',0,1,'',1589623683,1589623683,NULL),(253,228,'日志管理','fa fa-connectdevelop','system.log/index','','_self',0,1,'',1589623684,1589623684,NULL),(254,249,'平台管理','fa fa-wpforms','','','_self',7,1,'',1689413516,1689665113,NULL),(255,249,'曝光管理','fa fa-warning','cms.warn/index','','_self',6,1,'',1689413555,1689512712,NULL),(256,247,'系统配置','fa fa-list','system.config/index','','_self',0,1,'',1689416644,1689416644,NULL),(257,247,'配置属性','fa fa-list','config.attr/index','','_self',0,1,'',1689416666,1689416666,NULL),(258,247,'配置分组','fa fa-list','config.group/index','','_self',0,1,'',1689416685,1689416685,NULL),(259,249,'网站配置','fa fa-connectdevelop','config.config/index','','_self',0,1,'',1689416710,1689416710,NULL),(260,247,'配置列表','fa fa-list','config.index/index','','_self',0,1,'',1689416754,1689416754,NULL),(261,254,'收录平台','fa fa-backward','cms.plateback/index','','_self',5,1,'',1689512756,1689665105,NULL),(262,264,'省份管理','fa fa-asl-interpreting','cms.province/index','','_self',0,1,'',1689566074,1689566163,NULL),(263,264,'城市管理','fa fa-archive','cms.city/index','','_self',0,1,'',1689566104,1689566173,NULL),(264,249,'地区管理','fa fa-area-chart','','','_self',0,1,'',1689566153,1689566153,NULL),(265,254,'平台列表','fa fa-list','cms.plateform/index','','_self',9,1,'',1689665128,1689665139,NULL);
/*!40000 ALTER TABLE `pz_system_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_system_node`
--

DROP TABLE IF EXISTS `pz_system_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_system_node` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `node` varchar(100) DEFAULT NULL COMMENT '节点代码',
  `title` varchar(500) DEFAULT NULL COMMENT '节点标题',
  `type` tinyint(1) DEFAULT 3 COMMENT '节点类型（1：控制器，2：节点）',
  `is_auth` tinyint(1) unsigned DEFAULT 1 COMMENT '是否启动RBAC权限控制',
  `create_time` int(10) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `node` (`node`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='系统节点表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_system_node`
--

LOCK TABLES `pz_system_node` WRITE;
/*!40000 ALTER TABLE `pz_system_node` DISABLE KEYS */;
INSERT INTO `pz_system_node` VALUES (1,'system.admin','管理员管理',1,1,1589580432,1589580432),(2,'system.admin/index','列表',2,1,1589580432,1589580432),(3,'system.admin/add','添加',2,1,1589580432,1589580432),(4,'system.admin/edit','编辑',2,1,1589580432,1589580432),(5,'system.admin/password','编辑',2,1,1589580432,1589580432),(6,'system.admin/delete','删除',2,1,1589580432,1589580432),(7,'system.admin/modify','属性修改',2,1,1589580432,1589580432),(8,'system.admin/export','导出',2,1,1589580432,1589580432),(9,'system.auth','角色权限管理',1,1,1589580432,1589580432),(10,'system.auth/authorize','授权',2,1,1589580432,1589580432),(11,'system.auth/saveAuthorize','授权保存',2,1,1589580432,1589580432),(12,'system.auth/index','列表',2,1,1589580432,1589580432),(13,'system.auth/add','添加',2,1,1589580432,1589580432),(14,'system.auth/edit','编辑',2,1,1589580432,1589580432),(15,'system.auth/delete','删除',2,1,1589580432,1589580432),(16,'system.auth/export','导出',2,1,1589580432,1589580432),(17,'system.auth/modify','属性修改',2,1,1589580432,1589580432),(18,'system.config','系统配置管理',1,1,1589580432,1589580432),(19,'system.config/index','列表',2,1,1589580432,1589580432),(20,'system.config/save','保存',2,1,1589580432,1589580432),(21,'system.menu','菜单管理',1,1,1589580432,1589580432),(22,'system.menu/index','列表',2,1,1589580432,1589580432),(23,'system.menu/add','添加',2,1,1589580432,1589580432),(24,'system.menu/edit','编辑',2,1,1589580432,1589580432),(25,'system.menu/delete','删除',2,1,1589580432,1589580432),(26,'system.menu/modify','属性修改',2,1,1589580432,1589580432),(27,'system.menu/getMenuTips','添加菜单提示',2,1,1589580432,1589580432),(28,'system.menu/export','导出',2,1,1589580432,1589580432),(29,'system.node','系统节点管理',1,1,1589580432,1589580432),(30,'system.node/index','列表',2,1,1589580432,1589580432),(31,'system.node/refreshNode','系统节点更新',2,1,1589580432,1589580432),(32,'system.node/clearNode','清除失效节点',2,1,1589580432,1589580432),(33,'system.node/add','添加',2,1,1589580432,1589580432),(34,'system.node/edit','编辑',2,1,1589580432,1589580432),(35,'system.node/delete','删除',2,1,1589580432,1589580432),(36,'system.node/export','导出',2,1,1589580432,1589580432),(37,'system.node/modify','属性修改',2,1,1589580432,1589580432),(38,'system.uploadfile','上传文件管理',1,1,1589580432,1589580432),(39,'system.uploadfile/index','列表',2,1,1589580432,1589580432),(40,'system.uploadfile/add','添加',2,1,1589580432,1589580432),(41,'system.uploadfile/edit','编辑',2,1,1589580432,1589580432),(42,'system.uploadfile/delete','删除',2,1,1589580432,1589580432),(43,'system.uploadfile/export','导出',2,1,1589580432,1589580432),(44,'system.uploadfile/modify','属性修改',2,1,1589580432,1589580432),(45,'mall.cate','商品分类管理',1,1,1589580432,1589580432),(46,'mall.cate/index','列表',2,1,1589580432,1589580432),(47,'mall.cate/add','添加',2,1,1589580432,1589580432),(48,'mall.cate/edit','编辑',2,1,1589580432,1589580432),(49,'mall.cate/delete','删除',2,1,1589580432,1589580432),(50,'mall.cate/export','导出',2,1,1589580432,1589580432),(51,'mall.cate/modify','属性修改',2,1,1589580432,1589580432),(52,'mall.goods','商城商品管理',1,1,1589580432,1589580432),(53,'mall.goods/index','列表',2,1,1589580432,1589580432),(54,'mall.goods/stock','入库',2,1,1589580432,1589580432),(55,'mall.goods/add','添加',2,1,1589580432,1589580432),(56,'mall.goods/edit','编辑',2,1,1589580432,1589580432),(57,'mall.goods/delete','删除',2,1,1589580432,1589580432),(58,'mall.goods/export','导出',2,1,1589580432,1589580432),(59,'mall.goods/modify','属性修改',2,1,1589580432,1589580432),(60,'system.quick','快捷入口管理',1,1,1589623188,1589623188),(61,'system.quick/index','列表',2,1,1589623188,1589623188),(62,'system.quick/add','添加',2,1,1589623188,1589623188),(63,'system.quick/edit','编辑',2,1,1589623188,1589623188),(64,'system.quick/delete','删除',2,1,1589623188,1589623188),(65,'system.quick/export','导出',2,1,1589623188,1589623188),(66,'system.quick/modify','属性修改',2,1,1589623188,1589623188),(67,'system.log','操作日志管理',1,1,1589623188,1589623188),(68,'system.log/index','列表',2,1,1589623188,1589623188),(69,'config.attr','config_attr',1,1,1689665828,1689665828),(70,'config.attr/index','列表',2,1,1689665828,1689665828),(71,'config.attr/add','添加',2,1,1689665828,1689665828),(72,'config.attr/edit','编辑',2,1,1689665828,1689665828),(73,'config.attr/delete','删除',2,1,1689665828,1689665828),(74,'config.attr/export','导出',2,1,1689665828,1689665828),(75,'config.attr/modify','属性修改',2,1,1689665828,1689665828),(76,'config.config','配置显示',1,1,1689665828,1689665828),(77,'config.config/index','列表',2,1,1689665828,1689665828),(78,'config.config/add','添加',2,1,1689665828,1689665828),(79,'config.config/edit','编辑',2,1,1689665828,1689665828),(80,'config.config/delete','删除',2,1,1689665828,1689665828),(81,'config.config/export','导出',2,1,1689665828,1689665828),(82,'config.config/modify','属性修改',2,1,1689665828,1689665828),(83,'config.group','config_group',1,1,1689665828,1689665828),(84,'config.group/index','列表',2,1,1689665828,1689665828),(85,'config.group/add','添加',2,1,1689665828,1689665828),(86,'config.group/edit','编辑',2,1,1689665828,1689665828),(87,'config.group/delete','删除',2,1,1689665828,1689665828),(88,'config.group/export','导出',2,1,1689665828,1689665828),(89,'config.group/modify','属性修改',2,1,1689665828,1689665828),(90,'config.index','web_config',1,1,1689665828,1689665828),(91,'config.index/index','列表',2,1,1689665828,1689665828),(92,'config.index/add','添加',2,1,1689665828,1689665828),(93,'config.index/edit','编辑',2,1,1689665828,1689665828),(94,'config.index/delete','删除',2,1,1689665828,1689665828),(95,'config.index/export','导出',2,1,1689665828,1689665828),(96,'config.index/modify','属性修改',2,1,1689665828,1689665828),(97,'cms.city','cms_city',1,1,1689665828,1689665828),(98,'cms.city/index','列表',2,1,1689665828,1689665828),(99,'cms.city/add','添加',2,1,1689665828,1689665828),(100,'cms.city/edit','编辑',2,1,1689665828,1689665828),(101,'cms.city/delete','删除',2,1,1689665828,1689665828),(102,'cms.city/export','导出',2,1,1689665828,1689665828),(103,'cms.city/modify','属性修改',2,1,1689665828,1689665828),(104,'cms.navs','cms_navs',1,1,1689665828,1689665828),(105,'cms.navs/index','列表',2,1,1689665828,1689665828),(106,'cms.navs/add','添加',2,1,1689665828,1689665828),(107,'cms.navs/edit','编辑',2,1,1689665828,1689665828),(108,'cms.navs/delete','删除',2,1,1689665828,1689665828),(109,'cms.navs/export','导出',2,1,1689665828,1689665828),(110,'cms.navs/modify','属性修改',2,1,1689665828,1689665828),(111,'cms.news','cms_news',1,1,1689665828,1689665828),(112,'cms.news/index','列表',2,1,1689665828,1689665828),(113,'cms.news/add','添加',2,1,1689665828,1689665828),(114,'cms.news/edit','编辑',2,1,1689665828,1689665828),(115,'cms.news/delete','删除',2,1,1689665828,1689665828),(116,'cms.news/export','导出',2,1,1689665828,1689665828),(117,'cms.news/modify','属性修改',2,1,1689665828,1689665828),(118,'cms.plateback','cms_plateback',1,1,1689665828,1689665828),(119,'cms.plateback/index','列表',2,1,1689665828,1689665828),(120,'cms.plateback/add','添加',2,1,1689665828,1689665828),(121,'cms.plateback/edit','编辑',2,1,1689665828,1689665828),(122,'cms.plateback/delete','删除',2,1,1689665828,1689665828),(123,'cms.plateback/export','导出',2,1,1689665828,1689665828),(124,'cms.plateback/modify','属性修改',2,1,1689665828,1689665828),(125,'cms.plateform','cms_plateform',1,1,1689665828,1689665828),(126,'cms.plateform/getCity','获取城市',2,1,1689665828,1689665828),(127,'cms.plateform/add','添加',2,1,1689665828,1689665828),(128,'cms.plateform/edit','编辑',2,1,1689665828,1689665828),(129,'cms.plateform/index','列表',2,1,1689665828,1689665828),(130,'cms.plateform/delete','删除',2,1,1689665828,1689665828),(131,'cms.plateform/export','导出',2,1,1689665828,1689665828),(132,'cms.plateform/modify','属性修改',2,1,1689665828,1689665828),(133,'cms.province','cms_province',1,1,1689665828,1689665828),(134,'cms.province/index','列表',2,1,1689665828,1689665828),(135,'cms.province/add','添加',2,1,1689665828,1689665828),(136,'cms.province/edit','编辑',2,1,1689665828,1689665828),(137,'cms.province/delete','删除',2,1,1689665828,1689665828),(138,'cms.province/export','导出',2,1,1689665828,1689665828),(139,'cms.province/modify','属性修改',2,1,1689665828,1689665828),(140,'cms.warn','cms_warn',1,1,1689665828,1689665828),(141,'cms.warn/index','列表',2,1,1689665828,1689665828),(142,'cms.warn/add','添加',2,1,1689665828,1689665828),(143,'cms.warn/edit','编辑',2,1,1689665828,1689665828),(144,'cms.warn/delete','删除',2,1,1689665828,1689665828),(145,'cms.warn/export','导出',2,1,1689665828,1689665828),(146,'cms.warn/modify','属性修改',2,1,1689665828,1689665828);
/*!40000 ALTER TABLE `pz_system_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_system_quick`
--

DROP TABLE IF EXISTS `pz_system_quick`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_system_quick` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL COMMENT '快捷入口名称',
  `icon` varchar(100) DEFAULT NULL COMMENT '图标',
  `href` varchar(255) DEFAULT NULL COMMENT '快捷链接',
  `sort` int(11) DEFAULT 0 COMMENT '排序',
  `status` tinyint(1) unsigned DEFAULT 1 COMMENT '状态(1:禁用,2:启用)',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `create_time` int(11) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(11) DEFAULT NULL COMMENT '更新时间',
  `delete_time` int(11) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='系统快捷入口表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_system_quick`
--

LOCK TABLES `pz_system_quick` WRITE;
/*!40000 ALTER TABLE `pz_system_quick` DISABLE KEYS */;
INSERT INTO `pz_system_quick` VALUES (1,'管理员管理','fa fa-user','system.admin/index',0,1,'',1589624097,1689823014,NULL),(2,'角色管理','fa fa-bitbucket-square','system.auth/index',1,1,'',1589624772,1689823027,NULL),(3,'网站配置','fa fa-connectdevelop','cms.config/index',6,1,'',1589624097,1689822979,NULL),(6,'曝光管理','fa fa-warning','cms.warn/index',5,1,'',1589624772,1689822976,NULL),(7,'收录平台','fa fa-asterisk','cms.plateback/index',4,1,'',1589624097,1689822974,NULL),(8,'平台列表','fa fa-align-center','cms.plateform/index',3,1,'',1589624772,1689822972,NULL),(10,'新闻管理','fa fa-address-card-o','cms.news/index',2,1,'',1589624097,1689822968,NULL),(11,'栏目管理','fa fa-list','cms.navs/index',7,1,'',1589624772,1689823043,NULL);
/*!40000 ALTER TABLE `pz_system_quick` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pz_system_uploadfile`
--

DROP TABLE IF EXISTS `pz_system_uploadfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pz_system_uploadfile` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `upload_type` varchar(20) NOT NULL DEFAULT 'local' COMMENT '存储位置',
  `original_name` varchar(255) DEFAULT NULL COMMENT '文件原名',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '物理路径',
  `image_width` varchar(30) NOT NULL DEFAULT '' COMMENT '宽度',
  `image_height` varchar(30) NOT NULL DEFAULT '' COMMENT '高度',
  `image_type` varchar(30) NOT NULL DEFAULT '' COMMENT '图片类型',
  `image_frames` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '图片帧数',
  `mime_type` varchar(100) NOT NULL DEFAULT '' COMMENT 'mime类型',
  `file_size` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '文件大小',
  `file_ext` varchar(100) DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `create_time` int(10) DEFAULT NULL COMMENT '创建日期',
  `update_time` int(10) DEFAULT NULL COMMENT '更新时间',
  `upload_time` int(10) DEFAULT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  KEY `upload_type` (`upload_type`),
  KEY `original_name` (`original_name`)
) ENGINE=InnoDB AUTO_INCREMENT=357 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='上传文件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pz_system_uploadfile`
--

LOCK TABLES `pz_system_uploadfile` WRITE;
/*!40000 ALTER TABLE `pz_system_uploadfile` DISABLE KEYS */;
INSERT INTO `pz_system_uploadfile` VALUES (286,'alioss','image/jpeg','https://lxn-99php.oss-cn-shenzhen.aliyuncs.com/upload/20191111/0a6de1ac058ee134301501899b84ecb1.jpg','','','',0,'image/jpeg',0,'jpg','',NULL,NULL,NULL),(287,'alioss','image/jpeg','https://lxn-99php.oss-cn-shenzhen.aliyuncs.com/upload/20191111/46d7384f04a3bed331715e86a4095d15.jpg','','','',0,'image/jpeg',0,'jpg','',NULL,NULL,NULL),(288,'alioss','image/x-icon','https://lxn-99php.oss-cn-shenzhen.aliyuncs.com/upload/20191111/7d32671f4c1d1b01b0b28f45205763f9.ico','','','',0,'image/x-icon',0,'ico','',NULL,NULL,NULL),(289,'alioss','image/jpeg','https://lxn-99php.oss-cn-shenzhen.aliyuncs.com/upload/20191111/28cefa547f573a951bcdbbeb1396b06f.jpg','','','',0,'image/jpeg',0,'jpg','',NULL,NULL,NULL),(290,'alioss','image/jpeg','https://lxn-99php.oss-cn-shenzhen.aliyuncs.com/upload/20191111/2c412adf1b30c8be3a913e603c7b6e4a.jpg','','','',0,'image/jpeg',0,'jpg','',NULL,NULL,NULL),(291,'alioss','timg (1).jpg','http://easyadmin.oss-cn-shenzhen.aliyuncs.com/upload/20191113/ff793ced447febfa9ea2d86f9f88fa8e.jpg','','','',0,'image/jpeg',0,'jpg','',1573612437,NULL,NULL),(296,'txcos','22243.jpg','https://easyadmin-1251997243.cos.ap-guangzhou.myqcloud.com/upload/20191114/2381eaf81208ac188fa994b6f2579953.jpg','','','',0,'image/jpeg',0,'jpg','',1573712153,NULL,NULL),(297,'local','timg.jpg','http://admin.host/upload/20200423/5055a273cf8e3f393d699d622b74f247.jpg','','','',0,'image/jpeg',0,'jpg','',1587614155,NULL,NULL),(298,'local','timg.jpg','http://admin.host/upload/20200423/243f4e59f1b929951ef79c5f8be7468a.jpg','','','',0,'image/jpeg',0,'jpg','',1587614269,NULL,NULL),(299,'local','head.jpg','http://admin.host/upload/20200512/a5ce9883379727324f5686ef61205ce2.jpg','','','',0,'image/jpeg',0,'jpg','',1589255649,NULL,NULL),(300,'local','896e5b87c9ca70e4.jpg','http://admin.host/upload/20200514/577c65f101639f53dbbc9e7aa346f81c.jpg','','','',0,'image/jpeg',0,'jpg','',1589427798,NULL,NULL),(301,'local','896e5b87c9ca70e4.jpg','http://admin.host/upload/20200514/98fc09b0c4ad4d793a6f04bef79a0edc.jpg','','','',0,'image/jpeg',0,'jpg','',1589427840,NULL,NULL),(302,'local','18811e7611c8f292.jpg','http://admin.host/upload/20200514/e1c6c9ef6a4b98b8f7d95a1a0191a2df.jpg','','','',0,'image/jpeg',0,'jpg','',1589438645,NULL,NULL),(316,'local','logo.jpg','http://xhshhxx.com/upload/20230715/bcafca79dc5e245df4f10a70d530e1f5.jpg','','','',0,'image/jpeg',0,'jpg','',1689417613,NULL,NULL),(317,'local','logo.png','upload/20230715/e8c17fb3e51af54d9d5b46a101e327ba.png','','','',0,'image/png',0,'png','',1689417829,NULL,NULL),(318,'local','logo.jpg','/upload/20230715/2ff996a9d0733e33267522001102d619.jpg','','','',0,'image/jpeg',0,'jpg','',1689417855,NULL,NULL),(319,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230716/629c40c7e49aa9c3b308cad48a51fd7e.png','','','',0,'image/png',0,'png','',1689486624,NULL,NULL),(320,'local','QQ截图20220824133218.png','/upload/20230716/fbce5184e2188c536f2b6eaf0d16035b.png','','','',0,'image/png',0,'png','',1689488112,NULL,NULL),(321,'local','QQ截图20220824100903.png','/upload/20230716/ac7278c4d494533532274e410b616ea6.png','','','',0,'image/png',0,'png','',1689488117,NULL,NULL),(322,'local','QQ截图20220824100645.png','/upload/20230716/2a6ac40d15990f0f65657a75757d1304.png','','','',0,'image/png',0,'png','',1689488306,NULL,NULL),(323,'local','QQ截图20220824133203.png','/upload/20230716/7b9594cf4204a4e31c90d211c0d93e16.png','','','',0,'image/png',0,'png','',1689488314,NULL,NULL),(324,'local','QQ截图20220824133218.png','/upload/20230716/1a0b3ef97227a7def95859a6e1a991aa.png','','','',0,'image/png',0,'png','',1689488314,NULL,NULL),(325,'local','QQ截图20220824100645.png','/upload/20230716/7a400047fd6a95ffeb1317e007394f96.png','','','',0,'image/png',0,'png','',1689515562,NULL,NULL),(326,'local','QQ截图20220824100903.png','/upload/20230716/991b9f598dddf16a0140ac096d045d8d.png','','','',0,'image/png',0,'png','',1689515634,NULL,NULL),(327,'local','QQ截图20220824100825.png','/upload/20230716/3dd51260103c94b7ed92d86f4d9f10df.png','','','',0,'image/png',0,'png','',1689515652,NULL,NULL),(328,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230716/abbc76b60a4325a3f151e6801b1daecf.png','','','',0,'image/png',0,'png','',1689515786,NULL,NULL),(329,'local','123.txt','/upload/20230716/a25c3bc931465235060793e393240576.txt','','','',0,'text/plain',0,'txt','',1689515982,NULL,NULL),(330,'local','1.js','/upload/20230716/f4eb69901bcc491ba0eefe275869f7fa.js','','','',0,'text/javascript',0,'js','',1689516016,NULL,NULL),(331,'local','1.js','/upload/20230716/9e3ac072547d149716bc26f72c71b79f.js','','','',0,'text/javascript',0,'js','',1689516077,NULL,NULL),(332,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230716/4ca40c2fc43c8c43a92ca48cb86220dc.png','','','',0,'image/png',0,'png','',1689517360,NULL,NULL),(333,'local','QQ截图20220824100825.png','/upload/20230716/a4ae6091e9d1f9c4b0c451cccf5b016f.png','','','',0,'image/png',0,'png','',1689517384,NULL,NULL),(334,'local','QQ截图20220824133203.png','/upload/20230716/e8840bcbca7f6ba183c2980b5eb4f1dd.png','','','',0,'image/png',0,'png','',1689517388,NULL,NULL),(335,'local','QQ截图20220824133218.png','/upload/20230716/4e57f4c05bcc02111081b24ec38f31ee.png','','','',0,'image/png',0,'png','',1689517392,NULL,NULL),(336,'local','QQ截图20221105225409.png','/upload/20230716/eca48f93adf0d84a5401800774711cc1.png','','','',0,'image/png',0,'png','',1689517396,NULL,NULL),(337,'local','QQ截图20220824100903.png','/upload/20230716/5825c1594691adc328617ba6a33f7664.png','','','',0,'image/png',0,'png','',1689518272,NULL,NULL),(338,'local','QQ截图20220824100825.png','/upload/20230716/71d6fc1119f493d09add4923577608b3.png','','','',0,'image/png',0,'png','',1689518565,NULL,NULL),(339,'local','QQ截图20220824100756.png','/upload/20230716/b28d6d7213efe3d9122811cf777d9fa4.png','','','',0,'image/png',0,'png','',1689518574,NULL,NULL),(340,'local','QQ截图20220824100903.png','/upload/20230716/074a5511df466f6a602b1ed78c9c720c.png','','','',0,'image/png',0,'png','',1689518635,NULL,NULL),(341,'local','QQ截图20220824100825.png','/upload/20230716/9d0c0a442c3a4438b9d7265d94270c1d.png','','','',0,'image/png',0,'png','',1689518673,NULL,NULL),(342,'local','QQ截图20220824100825.png','/upload/20230717/ebc0ab2f093fa6ba627f2650a33638ab.png','','','',0,'image/png',0,'png','',1689581225,NULL,NULL),(343,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230717/919e207d12be4cd6cadb0de2567a7b11.png','','','',0,'image/png',0,'png','',1689581329,NULL,NULL),(344,'local','logo.jpg','/upload/20230718/8e98f053a16123289431f33a9bb29a2d.jpg','','','',0,'image/jpeg',0,'jpg','',1689643653,NULL,NULL),(345,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230718/b97767d918ca9e772ad5b0c9ffde27a5.png','','','',0,'image/png',0,'png','',1689644315,NULL,NULL),(346,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230718/c1e9cf8e068d064ac6dede5ffff2f280.png','','','',0,'image/png',0,'png','',1689645309,NULL,NULL),(347,'local','logo.jpg','/upload/20230718/c67089b8d6e10356831e9694521215a5.jpg','','','',0,'image/jpeg',0,'jpg','',1689645316,NULL,NULL),(348,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230720/9d8737837fb43fb58a8575d1824ab580.png','','','',0,'image/png',0,'png','',1689819856,NULL,NULL),(349,'local','logo.png','/upload/20230720/45be182680f11320d2ce4df76dc373bb.png','','','',0,'image/png',0,'png','',1689819869,NULL,NULL),(350,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230720/bb1f148784bdfde3c36a759be1c84d53.png','','','',0,'image/png',0,'png','',1689819886,NULL,NULL),(351,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230720/b41035259d9fb0dd42c784cb4d6868d4.png','','','',0,'image/png',0,'png','',1689819971,NULL,NULL),(352,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230720/d9e2547c268ee3f438c625d1b6e7934a.png','','','',0,'image/png',0,'png','',1689820084,NULL,NULL),(353,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230720/ba8b4b9259de3a7549c005632d73ef1c.png','','','',0,'image/png',0,'png','',1689820104,NULL,NULL),(354,'local','logo.png','/upload/20230720/e7e3cae683e46bad47cdc991e77287a7.png','','','',0,'image/png',0,'png','',1689820117,NULL,NULL),(355,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230720/4821aeaaeca50ed1a5574967cc87d2fb.png','','','',0,'image/png',0,'png','',1689820239,NULL,NULL),(356,'local','3d8d888c-a4f7-48d5-b543-cf66bba84262.png','/upload/20230720/5950692c9d18646de9d7d5a47e906ed9.png','','','',0,'image/png',0,'png','',1689820277,NULL,NULL);
/*!40000 ALTER TABLE `pz_system_uploadfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'peizi'
--

--
-- Dumping routines for database 'peizi'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-20 12:26:08
